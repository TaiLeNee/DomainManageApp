Dùng JBCrypt để mã hóa mật khẩu
