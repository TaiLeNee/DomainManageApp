module QuanCaffeVMQ{
    requires java.sql;
}
